# Overleaf report project

Upload the **entire `docs/report/` folder** to Overleaf and set `main.tex` as
the main document. Select **pdfLaTeX**; all figures are native TikZ and no
external images or bibliography download is required.

Project layout:

- `main.tex`: document entry point and section order.
- `preamble.tex`: packages, colors, layout, TikZ styles, and callout boxes.
- `settings.tex`: title, date, and project macros.
- `sections/`: scope, model, algorithms, Part D design/results/failures,
  generator design, readiness, supplementary protocol, comparison, and final
  recommendation.
- `data/part_d_run_matrix.csv`: all 120 independently validated solver runs.
- `data/per_run_detail.tex`: generated LaTeX table of per-run size,
  feasibility, makespan, runtime, lower-bound gap, critical path, and
  utilization.
- `data/case_summary.tex`: generated LaTeX table of instance characteristics,
  feasibility totals, best method(s), bound gap, and runtime.
- `data/part_d_results.csv`: a retained compatibility copy that currently
  matches `part_d_run_matrix.csv` byte-for-byte. The exporter refreshes
  `part_d_run_matrix.csv`; `main.tex` does not read either CSV directly.

The final two report sections are algorithm comparison and solver
recommendation. The supplementary per-run table is included before them.
The report is self-contained for Overleaf; repository-oriented developer notes
are maintained separately under `docs/`.

To refresh the experiment package from the repository root after rebuilding
the C++ solvers and validator:

```powershell
python environment/part_d_runner.py --timeout 180
python environment/export_part_d_latex.py
```
